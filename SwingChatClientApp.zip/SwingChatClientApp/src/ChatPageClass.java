import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ChatPageClass {

    JPanel cardPanel;
    ObjectOutputStream writer;
    DefaultListModel<String> names;
    JLabel chat;
    JLabel username;
    JList<String> chatList;
    JScrollPane chatListPane;
    JTextArea chatArea;
    JTextField input;
    JButton send;
    JScrollPane chatAreaPane;
    JButton addNew;
    GridBagConstraints gbc;
    JLabel onlineStatus;
    private JPanel chatPage = new JPanel(new GridBagLayout());
    private User currentUser;

    public ChatPageClass(JPanel cardPanel, ObjectOutputStream writer) {
        this.cardPanel = cardPanel;
        this.writer = writer;
    }

    public JPanel getChatPage() {
        return chatPage;
    }

    public JPanel createChatPage() {
        chat = new JLabel("Chats");
        names = new DefaultListModel<>();
        username = new JLabel();
        username.setFont(new Font("Arial", Font.BOLD, 20));
        chatList = new JList<>(names);
        chatList.setFixedCellWidth(100);
        chatListPane = new JScrollPane(chatList);
        chatArea = new JTextArea(18, 15);
        chatArea.setEditable(false);
        input = new JTextField(30);
        send = new JButton("Send");
        chatAreaPane = new JScrollPane(chatArea);
        addNew = new JButton("Add New Chat");
        onlineStatus = new JLabel();
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.weighty = 1;
        chatPage.add(chat, gbc);

        gbc.gridx = 1;

        chatPage.add(addNew, gbc);

        gbc.gridx = 2;

        chatPage.add(username, gbc);

        gbc.gridx = 3;

        chatPage.add(onlineStatus, gbc);


        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.VERTICAL;
        gbc.insets = new Insets(0, 5, 5, 0);
        chatPage.add(chatListPane, gbc);


        gbc.weightx = 1;
        gbc.gridheight = 1;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        gbc.insets = new Insets(0, 0, 0, 5);
        gbc.fill = GridBagConstraints.BOTH;
        chatPage.add(chatAreaPane, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        chatPage.add(input, gbc);

        gbc.gridx = 3;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;

        chatPage.add(send, gbc);

        cardPanel.add(chatPage, "chatPage");


        addNew.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Enter the username");
            if (names.contains(name)) {
                JOptionPane.showMessageDialog(null, "Conversation already exist for this user");
            } else {
                RequestItem<String[]> req = new RequestItem<>();
                req.requestType = "new conversation";
                req.obj = new String[]{currentUser.getUsername(), name};
                try {

                    writer.writeObject(req);
                    writer.flush();

                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        send.addActionListener(e -> {
            String receiver = chatList.getSelectedValue();
            String sender = currentUser.getUsername();
            String msg = input.getText();
            System.out.println("Message: " + msg);
            System.out.println("receiver: " + receiver);

            if (receiver != null && !msg.equalsIgnoreCase("")) {
                System.out.println("inside the if block of the send button");
                Message message = new Message(msg, sender, receiver);
                RequestItem<Message> req = new RequestItem<>();
                req.requestType = "send message";
                req.obj = message;
                try {
                    System.out.println("before writing object");
                    writer.writeObject(req);
                    System.out.println("after writing object");
                    writer.flush();
                    System.out.println("after flush");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
            input.setText("");
        });

        input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    send.doClick();
                    input.setText("");
                }
            }
        });

        chatList.addListSelectionListener(e -> {
            chatArea.setText("");
            Conversation con = this.currentUser
                    .getConversations()
                    .stream()
                    .filter(conv -> conv.getName1().equals(chatList.getSelectedValue()) || conv.getName2().equals(chatList.getSelectedValue()))
                    .toList()
                    .get(0);

            con.getMessages().forEach(msg -> chatArea.append((msg.getSender().equals(currentUser.getUsername())
                    ? "You: "
                    : (msg.getSender() + ": ")) + msg.getMessage() + "\n"));
            chatArea.setCaretPosition(chatArea.getDocument().getLength());
            boolean status = con.getOnlineStatus().get(chatList.getSelectedValue());

            onlineStatus.setText(status ? "Online" : "Offline");
            onlineStatus.setForeground(status ? Color.GREEN : Color.RED);
        });

        return chatPage;
    }

    public void setUserName(String name) {
        this.username.setText(name);
    }

    public void showPage(String name) {
        CardLayout cl = (CardLayout) cardPanel.getLayout();
        cl.show(cardPanel, name);
    }


    public void loadChatList(Conversation[] conversations, User user) {
        String[] data = new String[conversations.length];
        for (int i = 0; i < conversations.length; i++) {
            data[i] = conversations[i].getName1().equals(user.getUsername())
                    ? conversations[i].getName2() : conversations[i].getName1();
            this.names.addElement(data[i]);
        }


    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public void displayPopup(String userNotFound) {
        JOptionPane.showMessageDialog(null, userNotFound);
    }
}
