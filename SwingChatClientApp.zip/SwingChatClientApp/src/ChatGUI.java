import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;

class Connection {
    public static Socket getConnection() {
        try {
            return new Socket("localhost", 1235);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

class Listener extends Thread {
    private Socket socket;
    private ChatGUI chatGUI;
    private ObjectInputStream reader;
    private ObjectOutputStream writer;

    public Listener(Socket socket, ChatGUI gui, ObjectInputStream reader, ObjectOutputStream writer) {
        this.socket = socket;
        this.chatGUI = gui;
        this.reader = reader;
        this.writer = writer;
    }

    @Override
    public void run() {
        new Thread(() -> {
            if (socket.isClosed()) JOptionPane.showMessageDialog(null, "Socket Closed");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }).start();
        while (true) {

            try {
                System.out.println("before reading");
                Request req = (Request) reader.readObject();
                System.out.println("before switch");
                System.out.println(req.requestType);
                switch (req.requestType) {
                    case "username already exist":
                        System.out.println("this is username already exist");
                        new Thread(() -> chatGUI.showRegisterError(req.requestType)).start();
                        break;
                    case "new user added":
                        RequestItem<User> reqItem = (RequestItem<User>) req;
                        new Thread(() -> {
                            chatGUI.setCurrentUser(reqItem.obj);
                            chatGUI.loadChatArea(new Conversation[]{});
                        }).start();
                        break;
                    case "login successful":
                        new Thread(() -> {
                            RequestItem<RequestItem[]> requestItem = (RequestItem<RequestItem[]>) req;
                            RequestItem[] items = requestItem.obj;
                            RequestItem<User> userItem = items[0];
                            RequestItem<Conversation[]> convItem = items[1];
//                            userItem.obj.getConversations().get(0).getMessages().forEach(msg -> System.out.println("Msg from user: " + msg.getMessage()));
                            chatGUI.setCurrentUser(userItem.obj);
                            chatGUI.loadChatArea(convItem.obj);
                        }).start();
                        break;
                    case "login invalid password", "login username not found":
                        new Thread(() -> {
                            chatGUI.loginError(req.requestType);
                        }).start();
                        break;
                    case "new conversation added":
                        new Thread(() -> {
                            RequestItem<Conversation> requestItem = (RequestItem<Conversation>) req;
                            Conversation conv = requestItem.obj;
                            System.out.println(conv.getName1());
                            chatGUI.addNewConversation(conv);
                        }).start();
                        break;
                    case "message sent":
                        new Thread(() -> {
                            RequestItem<Message> requestItem = (RequestItem<Message>) req;
                            Message msg = requestItem.obj;
                            chatGUI.sendMessage(msg);
                        }).start();
                        break;
                    case "online status change":
                        new Thread(() -> {
                            RequestItem<String[]> requestItem = (RequestItem<String[]>) req;
                            String name = requestItem.obj[0];
                            boolean status = requestItem.obj[1].equalsIgnoreCase("true") ? true : false;
                            chatGUI.changeUserStatus(name, status);
                        }).start();
                }
            } catch (SocketException e) {
                JOptionPane.showMessageDialog(null, "Connection closed: " + e.getMessage());
                break;
            } catch (IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }
    }
}

public class ChatGUI extends JFrame {

    Socket socket;
    ObjectInputStream reader;
    ObjectOutputStream writer;
    JPanel cardPanel = new JPanel(new CardLayout());
    LoginOrRegisterPageClass loginOrRegisterPageClass;
    LoginPageClass loginPageClass;
    RegisterPageClass registerPageClass;
    ChatPageClass chatPageClass;
    Listener listenerThread;
    User currentUser;


    public ChatGUI() {
        this.setName("Chat Application");
        this.setSize(550, 550);
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        socket = Connection.getConnection();
        System.out.println(socket);
        try {
            writer = new ObjectOutputStream(socket.getOutputStream());
            reader = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.loginOrRegisterPageClass = new LoginOrRegisterPageClass(cardPanel);
        this.loginOrRegisterPageClass.createLoginOrRegisterPage();

        this.loginPageClass = new LoginPageClass(cardPanel, writer);
        this.loginPageClass.createLoginPage();

        this.registerPageClass = new RegisterPageClass(cardPanel, writer);
        this.registerPageClass.createRegisterPage();

        this.chatPageClass = new ChatPageClass(cardPanel, writer);
        this.chatPageClass.createChatPage();

        this.showPage("loginOrRegisterPage");


        this.add(cardPanel);
        this.setVisible(true);

        this.listenerThread = new Listener(this.socket, this, reader, writer);
        this.listenerThread.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                RequestItem<String> req = new RequestItem<>();
                req.requestType = "disconnect";
                req.obj = currentUser.getUsername();
                writer.writeObject(req);
                writer.flush();
                reader.close();
                writer.close();
                listenerThread.interrupt();
                socket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }));

    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public void showPage(String name) {
        CardLayout cl = (CardLayout) cardPanel.getLayout();
        cl.show(cardPanel, name);
    }

    public void loadChatArea(Conversation[] convs) {
        this.getChatPageClass().setUserName(currentUser.getUsername());
        this.getChatPageClass().loadChatList(convs, currentUser);
        this.getChatPageClass().setCurrentUser(currentUser);
        System.out.println("load chat " + currentUser.getUsername());
        System.out.println("conv: " + currentUser.getConversations().size());
        this.showPage("chatPage");
    }


    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public ObjectInputStream getReader() {
        return reader;
    }

    public void setReader(ObjectInputStream reader) {
        this.reader = reader;
    }

    public ObjectOutputStream getWriter() {
        return writer;
    }

    public void setWriter(ObjectOutputStream writer) {
        this.writer = writer;
    }

    public JPanel getCardPanel() {
        return cardPanel;
    }

    public void setCardPanel(JPanel cardPanel) {
        this.cardPanel = cardPanel;
    }

    public LoginOrRegisterPageClass getLoginOrRegisterPageClass() {
        return loginOrRegisterPageClass;
    }

    public void setLoginOrRegisterPageClass(LoginOrRegisterPageClass loginOrRegisterPageClass) {
        this.loginOrRegisterPageClass = loginOrRegisterPageClass;
    }

    public LoginPageClass getLoginPageClass() {
        return loginPageClass;
    }

    public void setLoginPageClass(LoginPageClass loginPageClass) {
        this.loginPageClass = loginPageClass;
    }

    public RegisterPageClass getRegisterPageClass() {
        return registerPageClass;
    }

    public void setRegisterPageClass(RegisterPageClass registerPageClass) {
        this.registerPageClass = registerPageClass;
    }

    public ChatPageClass getChatPageClass() {
        return chatPageClass;
    }

    public void setChatPageClass(ChatPageClass chatPageClass) {
        this.chatPageClass = chatPageClass;
    }

    public Listener getListenerThread() {
        return listenerThread;
    }

    public void setListenerThread(Listener listenerThread) {
        this.listenerThread = listenerThread;
    }

    public void showRegisterError(String error) {
        this.registerPageClass.showError(error);
    }

    public void loginError(String error) {
        this.loginPageClass.showError(error);
    }

    public void newConvUserNotFound() {
        this.getChatPageClass().displayPopup("User not found");
    }

    public void addNewConversation(Conversation conv) {
        this.currentUser.getConversations().add(conv);
        String s = conv.getName1().equals(currentUser.getUsername()) ? conv.getName2() : conv.getName1();
        this.chatPageClass.names.addElement(s);
    }

    public void sendMessage(Message msg) {
        this.currentUser
                .getConversations()
                .stream()
                .filter(conv -> (conv.getName1().equals(msg.getSender()) || conv.getName2().equals(msg.getSender()))
                        && (conv.getName1().equals(msg.getReceiver()) || conv.getName2().equals(msg.getReceiver())))
                .toList()
                .get(0)
                .getMessages()
                .add(msg);
        if (currentUser.getUsername().equals(msg.getSender()))
            this.chatPageClass.chatArea.append("You: " + msg.getMessage() + "\n");
        else {
            System.out.println("Selected value: " + this.chatPageClass.chatList.getSelectedValue());
            System.out.println("Receiver: " + msg.getReceiver());
            String selectedValue = this.chatPageClass.chatList.getSelectedValue();
            if (selectedValue != null)
                if (selectedValue.equals(msg.getSender()))
                    this.chatPageClass.chatArea.append(msg.getSender() + ": " + msg.getMessage() + "\n");
        }
        this.chatPageClass.chatArea.setCaretPosition(chatPageClass.chatArea.getDocument().getLength());
    }

    public void changeUserStatus(String name, boolean status) {
        for (Conversation c : currentUser.getConversations()) {
            if (c.getName1().equals(name) || c.getName2().equals(name)) {
                c.getOnlineStatus().put(name, status);
                if (this.chatPageClass.chatList.getSelectedValue().equals(name)) {
                    this.chatPageClass.onlineStatus.setText(status ? "Online" : "Offline");
                }
            }
        }
    }
}
