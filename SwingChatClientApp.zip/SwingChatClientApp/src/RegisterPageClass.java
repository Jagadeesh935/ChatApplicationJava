import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Arrays;

public class RegisterPageClass {

    private JPanel registerPage = new JPanel(new GridBagLayout());
    ObjectOutputStream writer;
    JPanel cardPanel;

    JLabel register;
    JLabel usernameLabel;
    JLabel passwordLabel;
    JLabel cpasswordLabel;
    JTextField usernameBox;
    JPasswordField passwordBox;
    JPasswordField cpasswordBox;
    JButton registerButton;
    GridBagConstraints gbc;
    JLabel error;
    JButton back;


    public RegisterPageClass(JPanel cardPanel, ObjectOutputStream writer){
        this.writer = writer;
        this.cardPanel = cardPanel;
    }

    public JPanel getRegisterPage() {
        return registerPage;
    }

    public JPanel createRegisterPage(){
        register = new JLabel("Register");
        usernameLabel = new JLabel("Username");
        passwordLabel = new JLabel("Password");
        cpasswordLabel = new JLabel("Confirm Password");
        usernameBox = new JTextField(20);
        passwordBox = new JPasswordField(20);
        cpasswordBox = new JPasswordField(20);
        registerButton = new JButton("Register");
        error = new JLabel();
        back = new JButton("Back");
        gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weighty = 1;
        gbc.weightx = 1;
        register.setFont(new Font("Arial", Font.BOLD, 30));
        registerPage.add(register, gbc);



        gbc.gridx = 0;
        gbc.gridy = 1;
        error.setForeground(Color.RED);
        registerPage.add(error, gbc);

        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.SOUTH;
        registerPage.add(usernameLabel, gbc);

        gbc.gridx = 1;

        registerPage.add(usernameBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        registerPage.add(passwordLabel, gbc);

        gbc.gridx = 1;

        registerPage.add(passwordBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.NORTH;
        registerPage.add(cpasswordLabel, gbc);

        gbc.gridx = 1;

        registerPage.add(cpasswordBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0,0,0,5);
        gbc.anchor = GridBagConstraints.EAST;
        registerPage.add(back, gbc);

        gbc.gridx = 1;
        gbc.insets = new Insets(0,80,0,0);
        gbc.anchor = GridBagConstraints.WEST;
        registerPage.add(registerButton, gbc);

        cardPanel.add(registerPage, "registerPage");

        back.addActionListener(e -> {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "loginOrRegisterPage");
        });

        registerButton.addActionListener(e -> {
            String name = usernameBox.getText();
            String password = new String(passwordBox.getPassword());
            String cpassword = new String(cpasswordBox.getPassword());
            if(name.length() > 0){
                if (password.length() > 6){
                    if (password.equals(cpassword)){
                        RequestItem<String[]> req = new RequestItem<>();
                        req.requestType = "register";
                        req.obj = new String[]{name, password};

                        try {
                            writer.writeObject(req);
                            writer.flush();
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    } else {
                        error.setText("Both passwords should be equal");
                        passwordBox.setBorder(new LineBorder(Color.RED, 1));
                        cpasswordBox.setBorder(new LineBorder(Color.RED, 1));
                    }
                } else {
                    error.setText("Password should be atleast 6 characters long");
                    passwordBox.setBorder(new LineBorder(Color.RED, 1));
                }
            } else {
                error.setText("Name field shouldn't be blank");
            }

        });


        return registerPage;
    }

    public void showError(String error) {
        this.error.setText(error);
    }
}
