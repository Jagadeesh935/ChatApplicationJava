import java.io.Serializable;

public class Request implements Serializable {
    private static final long serialVersionUID = 1L;
    String requestType;
}

class RequestItem<T> extends Request implements Serializable{
    private static final long serialVersionUID = 5L;
    T obj;
}