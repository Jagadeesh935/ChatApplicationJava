import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Conversation implements Serializable {
    private static final long serialVersionUID = 3L;
    private static int tracker;
    private int conversationId;
    private String name1;
    private String name2;
    private HashMap<String, Boolean> onlineStatus = new HashMap<>();
    private List<Message> messages = new ArrayList<>();

    public Conversation(String person1, String person2, boolean onlineStatus) {
        this.conversationId = ++tracker;
        name1 = person1;
        name2 = person2;
        this.onlineStatus.put(name1, true);
        this.onlineStatus.put(name2, onlineStatus);
    }


    public HashMap<String, Boolean> getOnlineStatus() {
        return onlineStatus;
    }

    public void setOnlineStatus(HashMap<String, Boolean> onlineStatus) {
        this.onlineStatus = onlineStatus;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }


    public int getConversationId() {
        return conversationId;
    }

    public void setConversationId(int conversationId) {
        this.conversationId = conversationId;
    }


    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }
}
