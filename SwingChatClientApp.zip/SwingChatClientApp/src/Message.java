import java.io.Serializable;

public class Message implements Serializable {
    private static final long serialVersionUID = 4L;
    private static int tracker;
    private int messageId;
    private String message;
    private String sender;
    private String receiver;

    public Message(String message, String sender, String receiver) {
        this.message = message;
        this.sender = sender;
        this.receiver = receiver;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }
}
