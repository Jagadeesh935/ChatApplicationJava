import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class LoginPageClass {

    JPanel cardPanel;
    ObjectOutputStream writer;
    JLabel title;
    JLabel usernameLabel;
    JLabel passwordLabel;
    JTextField usernameBox;
    JPasswordField passwordBox;
    JButton loginButton;
    GridBagConstraints gbc;
    JLabel error;
    JButton back;
    private JPanel loginPage = new JPanel(new GridBagLayout());

    public LoginPageClass(JPanel cardPanel, ObjectOutputStream writer) {
        this.cardPanel = cardPanel;
        this.writer = writer;
    }

    public JPanel getLoginPage() {
        return loginPage;
    }

    public JPanel createLoginPage() {
        title = new JLabel("Login");
        usernameLabel = new JLabel("Username");
        passwordLabel = new JLabel("Password");
        usernameBox = new JTextField(20);
        passwordBox = new JPasswordField(20);
        loginButton = new JButton("Login");
        error = new JLabel();
        back = new JButton("Back");

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.anchor = GridBagConstraints.CENTER;
        title.setFont(new Font("Arial", Font.BOLD, 30));
        loginPage.add(title, gbc);

        gbc.gridy = 1;
        error.setForeground(Color.RED);
        loginPage.add(error, gbc);

        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.SOUTH;
        loginPage.add(usernameLabel, gbc);

        gbc.gridx = 1;

        loginPage.add(usernameBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.NORTH;
        loginPage.add(passwordLabel, gbc);

        gbc.gridx = 1;

        loginPage.add(passwordBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0, 0, 0, 5);
        gbc.anchor = GridBagConstraints.EAST;
        loginPage.add(back, gbc);

        gbc.gridx = 1;
        gbc.insets = new Insets(0, 100, 0, 0);
        gbc.anchor = GridBagConstraints.WEST;
        loginPage.add(loginButton, gbc);

        cardPanel.add(loginPage, "loginPage");

        back.addActionListener(e -> {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "loginOrRegisterPage");
        });


        loginButton.addActionListener(e -> {
            String username = usernameBox.getText();
            String password = new String(passwordBox.getPassword());

            if (username.length() == 0 || password.length() == 0) {
                error.setText("Please enter the username and password");
            } else {

                RequestItem<String[]> req = new RequestItem<>();
                req.requestType = "login";
                req.obj = new String[]{username, password};
                try {
                    writer.writeObject(req);
                    writer.flush();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

            }

        });

        return loginPage;
    }

    public void showError(String error) {
        System.out.println("error statement before");
        this.error.setText(error);
    }
}
