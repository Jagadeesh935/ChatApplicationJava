import javax.swing.*;
import java.awt.*;
import java.io.ObjectOutputStream;

public class LoginOrRegisterPageClass {

    private JPanel loginOrRegister = new JPanel(new GridBagLayout());
    JPanel cardPanel;

    JButton loginButton;
    JLabel or;
    JButton registerButton;
    GridBagConstraints gbc;

    public LoginOrRegisterPageClass(JPanel cardPanel){
        this.cardPanel = cardPanel;
    }

    public JPanel getLoginOrRegister() {
        return loginOrRegister;
    }

    public JPanel createLoginOrRegisterPage(){
        loginButton = new JButton("Login");
        or = new JLabel("-----OR-----");
        registerButton = new JButton("Register");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.anchor = GridBagConstraints.SOUTH;

        loginOrRegister.add(loginButton, gbc);

        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        loginOrRegister.add(or,gbc);
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        loginOrRegister.add(registerButton, gbc);

        cardPanel.add(loginOrRegister, "loginOrRegisterPage");

        loginButton.addActionListener(e -> this.showPage("loginPage"));

        registerButton.addActionListener(e -> this.showPage("registerPage"));

        return loginOrRegister;
    }

    public void showPage(String name){
        CardLayout cl = (CardLayout) cardPanel.getLayout();
        cl.show(cardPanel, name);
    }
}
