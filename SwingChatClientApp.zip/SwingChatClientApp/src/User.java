import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable {
    private static final long serialVersionUID = 2L;
    private String username;
    private String password;
    private List<Conversation> conversations = new ArrayList<>();
    private transient ObjectOutputStream writer;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public ObjectOutputStream getWriter() {
        return writer;
    }

    public void setWriter(ObjectOutputStream writer) {
        this.writer = writer;
    }

    public List<Conversation> getConversations() {
        return conversations;
    }

    public void setConversations(List<Conversation> conversations) {
        this.conversations = conversations;
    }

    public void addConversation(Conversation name){
        System.out.println("inside class conv size before adding: " + conversations.size());
        conversations.add(name);
        System.out.println("inside class conv size after adding: " + conversations.size());
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
