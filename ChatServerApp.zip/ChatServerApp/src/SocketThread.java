import javax.swing.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;

public class SocketThread extends Thread {
    private Socket socket;
    private ObjectInputStream reader;
    private ObjectOutputStream writer;


    public SocketThread(Socket socket) {
        this.socket = socket;
        try {
            reader = new ObjectInputStream(this.socket.getInputStream());
            writer = new ObjectOutputStream(this.socket.getOutputStream());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Socket getSocket() {
        return socket;
    }



    public void login(Request request) throws IOException {
        RequestItem<String[]> reqItem = (RequestItem<String[]>) request;
        String[] data = (String[]) reqItem.obj;
        String username = data[0];
        String password = data[1];
        User user = Main.getUser(username);

        RequestItem<RequestItem[]> req = new RequestItem<>();
        req.obj = null;
        if (user != null) {
            if (user.getPassword().equals(password)) {
                req.requestType = "login successful";
                user.setWriter(writer);
                RequestItem<User> firstItem = new RequestItem<>();
                firstItem.obj = user;
                RequestItem<Conversation[]> convs = new RequestItem<>();
                convs.obj = convertListToArray(user.getConversations());
                req.obj = new RequestItem[]{firstItem, convs};
                writer.writeObject(req);
                writer.flush();
                user.getConversations().forEach(conv -> {
                    conv.getOnlineStatus().put(user.getUsername(), true);
                    String name = (conv.getName1().equals(user.getUsername())) ? conv.getName2() : conv.getName1();
                    RequestItem<String[]> reqs = new RequestItem<>();
                    reqs.requestType = "online status change";
                    reqs.obj = new String[]{user.getUsername(), "true"};
                    ObjectOutputStream receiversWriter = Main.getUser(name).getWriter();
                    if (receiversWriter != null) {
                        try {
                            receiversWriter.writeObject(reqs);
                            receiversWriter.flush();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            } else {
                req.requestType = "login invalid password";
                writer.writeObject(req);
                writer.flush();
            }
        } else {
            req.requestType = "login username not found";
            writer.writeObject(req);
            writer.flush();
        }
    }

    public Conversation[] convertListToArray(List<Conversation> list){
        Conversation[] arr = new Conversation[list.size()];
        for (int i = 0; i< list.size(); i++){
            arr[i] = list.get(i);
        }
        return arr;
    }

    public void createNewConversation(Request request) throws IOException {
        RequestItem<String[]> reqItem = (RequestItem<String[]>) request;
        String[] data = reqItem.obj;
        String senderName = data[0];
        String receiverName = data[1];
        User receiver = Main.getUser(receiverName);
        RequestItem<Conversation> req = new RequestItem<>();
        req.obj = null;
        if (receiver == null) {
            req.requestType = "new conversation username not found";
            writer.writeObject(req);
            writer.flush();
        }else {
            User sender = Main.getUser(senderName);
            Conversation conv = new Conversation(senderName,receiverName, Main.getUser(receiverName).getWriter() != null);
            sender.addConversation(conv);
            System.out.println("calling conv size after adding: " + sender.getConversations().size());
            receiver.addConversation(conv);
            req.requestType = "new conversation added";
            req.obj = conv;
            writer.writeObject(req);
            writer.flush();
            ObjectOutputStream receiversWriter = receiver.getWriter();
            if (receiversWriter != null){
                req.obj = conv;
                receiversWriter.writeObject(req);
                receiversWriter.flush();
            }
        }

    }

    public void newUser(RequestItem<String[]> request) throws IOException {
        String[] data =  request.obj;
        String result = Main.addUser(data[0], data[1]);
        RequestItem<User> req = new RequestItem<>();
        if (result.equalsIgnoreCase("username already exist")){
            req.requestType = result;
            req.obj = null;
            writer.writeObject(req);
            writer.flush();
        } else if(result.equalsIgnoreCase("new user added")){
            req.requestType = result;
            req.obj = Main.getUser(data[0]);
            assert req.obj != null;
            req.obj.setWriter(writer);
            System.out.println("Writer set for " + data[0]);
            writer.writeObject(req);
            writer.flush();
            System.out.println("end of new user creation");
        }
    }

    public void sendMessage(Request request) throws IOException {
        RequestItem<Message> requestItem = (RequestItem<Message>) request;
        Message message = requestItem.obj;
        Conversation conv = Main.getConversation(message.getSender(), message.getReceiver());
        conv.getMessages().add(message);
        request.requestType = "message sent";
        writer.writeObject(request);
        writer.flush();
        System.out.println("Message send to sender");
        ObjectOutputStream receiversWriter = Main.getUser(message.getReceiver()).getWriter();
        if (receiversWriter != null){
            receiversWriter.writeObject(request);
            receiversWriter.flush();
            System.out.println("Message send to the receiver");
        }
    }

    public void disconnectClient(Request request){
        RequestItem<String> requestItem = (RequestItem<String>) request;
        User user = Main.getUser(requestItem.obj);
        user.setWriter(null);
        user.getConversations().forEach(conv -> {
            conv.getOnlineStatus().put(user.getUsername(), false);
            String name = (conv.getName1().equals(user.getUsername())) ? conv.getName2() : conv.getName1();
            RequestItem<String[]> req = new RequestItem<>();
            req.requestType = "online status change";
            req.obj = new String[]{user.getUsername(), "false"};
            ObjectOutputStream receiversWriter = Main.getUser(name).getWriter();
            if (receiversWriter != null) {
                try {
                    receiversWriter.writeObject(req);
                    receiversWriter.flush();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void run() {

        boolean run = true;
        while (run) {
            try {
                System.out.println("Listening to new request");
                Request request = (Request) reader.readObject();
                System.out.println(request.requestType);
                switch (request.requestType) {
                    case "register":
                        RequestItem<String[]> item = (RequestItem<String[]>) request;
                        newUser(item);
                        break;
                    case "login":
                        login(request);
                        break;
                    case "new conversation":
                        createNewConversation(request);
                        break;
                    case "send message":
                        sendMessage(request);
                        break;
                    case "disconnect":
                        run = false;
                        disconnectClient(request);
                        System.out.println("Client disconnected");
                }
            } catch (SocketException e){
                JOptionPane.showMessageDialog(null,"server socket closed: " + e.getMessage());
                try {
                    writer.close();
                    socket.close();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                break;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

}
