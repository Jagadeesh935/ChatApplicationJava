import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {

    static List<User> users = new ArrayList<>();

    public static void main(String[] args) {

        try {
            File file = new File("users.ser");
            if (file.exists()) {
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("users.ser"));
                users = (List<User>) ois.readObject();
                ois.close();
                System.out.println("Objects deserialized");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("users.ser"));
                oos.writeObject(users);
                oos.close();
                System.out.println("Serialization complete");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }));

        try {
            ServerSocket server = new ServerSocket(1235);
            while (true) {
                Socket socket = server.accept();
                SocketThread thread = new SocketThread(socket);
                thread.start();
                System.out.println("New thread created");
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }

    public static String addUser(String name, String password) {
        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(name)) {
                return "username already exist";
            }
        }
        users.add(new User(name, password));
        System.out.println("New user added:" + name);
        return "new user added";
    }

    public static User getUser(String name) {
        for (User user : users) {
            if (user.getUsername().equals(name)) return user;
        }

        return null;
    }

    public static Conversation getConversation(String sender, String receiver) {
        User user = getUser(sender);
        assert user != null;
        return user.getConversations()
                .stream()
                .filter(conv -> (conv.getName1().equals(sender) || conv.getName2().equals(sender))
                        && (conv.getName1().equals(receiver) || conv.getName2().equals(receiver))).toList().get(0);
    }
}